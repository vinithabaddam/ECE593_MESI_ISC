We are still working on 
	Improvising tester random stimulus
	Making bfm more readable and easily understandable
	Scoreboard functionality
